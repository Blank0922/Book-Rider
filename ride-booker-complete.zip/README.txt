Ride Booker - local site
Files:
- index.html
- booking.html (uses Google Maps & PayPal; replace YOUR_API_KEY and YOUR_CLIENT_ID)
- payment.html
- signup.html
- login.html
- confirmation.html
- styles.css
Instructions: unzip and open index.html. For booking to work, add Google API key and PayPal client id as noted in booking.html